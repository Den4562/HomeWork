﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int counter = 0;
        public MainWindow()
        {
            InitializeComponent();
        }
        bool Check(string name, string price, string count)
        {
            if (name == "")
            {
                
               throw new FormatException("Введіть назву товару");
            }
            if (price == "")
            {
                throw new FormatException("Введіть ціну товару");

            }
            if (count== "")
            {
                throw new FormatException("Введіть кількість товару");
            }
            return true;
        }
        private void AddGood_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool check = Check(tbName.Text, tbPrice.Text, tbCount.Text);
                Good good = new Good(tbName.Text, Convert.ToInt32(tbPrice.Text), Convert.ToInt32(tbCount.Text));
                TreeViewItem item = new TreeViewItem();
                item.Header = good.ToString();
                item.Tag = good;
                if (check)
                {
                    if (Category.SelectedItem != null)
                    {
                        switch (Category.SelectedIndex)
                        {
                            case 0:
                                {
                                    Tech.Items.Add(item);
                                }
                                break;
                            case 1:
                                {
                                    Home.Items.Add(item);
                                }
                                break;
                            case 2:
                                {
                                    Kitch.Items.Add(item);
                                }
                                break;
                        }
                        tvTree.Items.Refresh();
                    }
                    else
                    {
                        throw new Exception("Виберіть категорію");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Увага", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteGood_Click(object sender, RoutedEventArgs e)
        {
           
        }
    }
    public class Good
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public int Count { get; set; }
        public Good(string name, int price, int count)
        {
            Name = name;
            Price = price;
            Count = count;
        }
        public override string ToString()
        {
            return Name + " " + Price + " " + Count;
        }
    }
}
